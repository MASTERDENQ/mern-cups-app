module.exports = {
    //mongodbConnection: 'mongodb+srv://39:sanKyuu@ap-cups-98ffm.azure.mongodb.net/test?retryWrites=true&w=majority'
    mongoURI: 'mongodb://localhost/testdb'
};